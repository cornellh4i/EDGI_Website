#!/usr/bin/env python
# coding: utf-8

import AllPrograms_db

focus_year = 2022
AllPrograms_db.make_per_1000(focus_year)
